//
//  ViewController.swift
//  swift-workshop
//
//  Created by David Ng on 18/1/2017.
//  Copyright © 2017 Skygear. All rights reserved.
//

import UIKit
import SKYKit

class ViewController: UIViewController {

    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func signUpField(_ sender: UIButton) {
        SKYContainer.default().signup(withEmail: emailField.text, password: passwordField.text) { (user, error) in
            if (error != nil) {
                //self.showAlert(error as! NSError)
                let alert = UIAlertController(title: "Alert", message: error as! String, preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Click", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                
                return
            }
            print("Signed up as: \(user)")
        }
    }
    
    @IBAction func logInField(_ sender: Any) {
        SKYContainer.default().login(withEmail: emailField.text, password: passwordField.text) { (user, error) in
            if (error != nil) {
                //self.showAlert(error as! NSError)
                
                print("Loggged in as: \(error as! NSError)")
                /*
                let alert = UIAlertController(title: "Alert", message: "Message", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Click", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                */
                return
            }
            print("Logged in as: \(user)")
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

