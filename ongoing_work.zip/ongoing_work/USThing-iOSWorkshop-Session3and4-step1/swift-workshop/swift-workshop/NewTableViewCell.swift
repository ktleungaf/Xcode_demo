//
//  NewTableViewCell.swift
//  swift-workshop
//
//  Created by Lawrencé on 12/4/2017.
//  Copyright © 2017 Skygear. All rights reserved.
//

import UIKit

class NewTableViewCell:
UITableViewCell {
    @IBOutlet weak var titleLabel: UILabel!

    @IBOutlet weak var contentField: UILabel!
    
    @IBOutlet weak var photoImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
