//
//  PhotoTableViewController.swift
//  swift-workshop
//
//  Created by Lawrencé on 12/4/2017.
//  Copyright © 2017 Skygear. All rights reserved.
//

import UIKit
import SKYKit

class PhotoTableViewController: UITableViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {

    var posts = [Any]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let publicDB = SKYContainer.default().publicCloudDatabase
        let query = SKYQuery(recordType: "post", predicate: nil)
        let sortDescriptor = NSSortDescriptor(key: "_created_at", ascending: false)
        query?.sortDescriptors = [sortDescriptor]
        
        publicDB?.perform(query!, completionHandler: { posts, error in
            if let error = error {
                print("Error retrieving photos: \(error)")
                //self.onCompletion(posts!)
            } else {
                self.onCompletion(posts!)
            }
        })

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    func onCompletion(_ posts:[Any]) {
        print("There are \(posts.count) posts")
        print(posts)
        self.posts = posts
        self.tableView.reloadData()
    }
    
    @IBAction func addButtonPressed(_ sender: Any) {
        self.presentImagePicker()
    }

    
    func askForTitle(asset: SKYAsset ){
        let alertController = UIAlertController(title: "Details", message: "Please give a title and the content:", preferredStyle: .alert)
        
        let confirmAction = UIAlertAction(title: "Confirm", style: .default) {(_) in
            var titleField = (alertController.textFields?[0])! as UITextField
            var contentField = (alertController.textFields?[1])! as UITextField
        
        //Upload
        let post = SKYRecord(recordType: "post")
        post?.setObject(titleField.text, forKey: "title" as NSCopying)
        post?.setObject(contentField.text, forKey: "content" as NSCopying)
        post?.setObject(SKYSequence(), forKey: "order" as NSCopying)
        post?.setObject(asset, forKey: "asset" as NSCopying)
        post?.setObject(false, forKey: "done" as NSCopying)
        
        SKYContainer.default().publicCloudDatabase.save(post, completion:{ (record, error) in
            if (error != nil){
                print("error saving post: \(post)")
                return
        }
        
            
            
        self.posts.insert(record, at: 0)
        let indexPath = IndexPath(row: 0, section: 0)
        self.tableView.insertRows(at: [indexPath as IndexPath], with: UITableViewRowAnimation.automatic)
        
        })
    }
    let cancelAction = UIAlertAction(title: "Cancel", style: .cancel){(_) in}
    
    alertController.addTextField { (textField) in
        textField.placeholder = "Title"
    }

    alertController.addTextField { (textField) in
        textField.placeholder = "Content"
    }

    alertController.addAction(confirmAction)
    alertController.addAction(cancelAction)
    
    self.present(alertController, animated: true, completion: nil)
}

    func presentImagePicker() {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.modalPresentationStyle = .popover
        imagePicker.allowsEditing = false
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage,
            let resizedImageData = PhotoHelper.resize(image: pickedImage, maxWidth: 800, quality: 0.9) {
            
            
            PhotoHelper.upload(imageData: resizedImageData, onCompletion: {uploadedAsset in
                if (uploadedAsset != nil) {
                    print("has photo")
                    self.askForTitle(asset: uploadedAsset!)
                } else {
                    print("no photo")
                }
            })

            
            
        }
        dismiss(animated: true, completion: {
            
        })
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return posts.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let newsCell = tableView.dequeueReusableCell(withIdentifier: "newsCell", for: indexPath) as! NewTableViewCell
        
        let record = self.posts[indexPath.row]
        let post = record as? SKYRecord
        newsCell.titleLabel.text = post?.object(forKey: "title") as! String
        newsCell.contentField.text = post?.object(forKey: "content") as! String
        
        let imageAsset = post?.object(forKey: "asset") as? SKYAsset
        print(imageAsset?.url)
        
        //asyncTask
        /*drawback: load every image everytime and images will flash when scrolling back or scrolling down the images
         Solution: there are some libraries like AsyncImage and alogirthm LRU (Least Recently Used) algorithm to maintain images stored in queues by enqueueing and dequeing and therefore cache images
        */
        newsCell.photoImageView.image = UIImage(named: "Placeholder")
        if let imageUrl = imageAsset?.url {
            URLSession.shared.dataTask(with: imageUrl) { data, response, error in
                if let imageData = data {
                    DispatchQueue.main.async {
                        newsCell.photoImageView.image = UIImage(data: imageData)
                    }
                }
                }.resume()
        }
        

        
        return newsCell
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
